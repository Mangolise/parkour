
plugins {
    id("java")
    id("java-library")
    id("io.github.goooler.shadow") version("8.1.7")
}

group = "net.mangolise"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
    maven("https://maven.serble.net/snapshots/")
    maven("https://maven.serble.net/private/") {
        credentials {
            username = System.getenv("SERBLE_REPO_USERNAME")!!
            password = System.getenv("SERBLE_REPO_PASSWORD")!!
        }
    }
}

dependencies {
    implementation("net.mangolise:mango-game-sdk:latest")
    implementation("net.mangolise:mango-commons:latest")
    implementation("net.minestom:minestom-snapshots:6c5cd6544e")
    implementation("dev.hollowcube:polar:1.11.1")

    // https://mvnrepository.com/artifact/org.gradle/gradle-core
    compileOnly(gradleApi())
}

tasks.withType<Jar> {
    manifest {
        // Change this to your main class
        attributes["Main-Class"] = "net.mangolise.paintball.Test"
    }
}

tasks.register("packageWorlds", net.mangolise.gamesdk.gradle.PackageWorldTask::class.java)
tasks.processResources {
    dependsOn("packageWorlds")
}
