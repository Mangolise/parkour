package net.mangolise.parkour;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import net.mangolise.gamesdk.BaseGame;
import net.mangolise.gamesdk.log.Log;
import net.minestom.server.MinecraftServer;
import net.minestom.server.coordinate.Pos;
import net.minestom.server.entity.GameMode;
import net.minestom.server.entity.Player;
import net.minestom.server.entity.attribute.Attribute;
import net.minestom.server.event.player.AsyncPlayerConfigurationEvent;
import net.minestom.server.event.player.PlayerMoveEvent;
import net.minestom.server.instance.Instance;
import net.minestom.server.instance.anvil.AnvilLoader;
import net.minestom.server.instance.block.Block;
import net.minestom.server.tag.Tag;

import java.io.IOException;
import java.util.*;

public class ParkourGame extends BaseGame<ParkourGame.Config> {
    private static final Tag<Integer> CURRENT_CHECKPOINT_TAG = Tag.Integer("current_checkpoint").defaultValue(0);

    public ParkourGame(Config config) {
        super(config);
    }

    @Override
    public void setup() {
        //super.setup();
        Instance instance = MinecraftServer.getInstanceManager().createInstanceContainer(new AnvilLoader("worlds/" + config.worldName));
        instance.enableAutoChunkLoad(true);

        // Load MapData
        MapData mapData = new MapData(new ArrayList<>());
        try {
            String stringJson = new String(Objects.requireNonNull(ClassLoader.getSystemResourceAsStream(
                    "worlds/" + config.worldName + "/data.json")).readAllBytes());

            Gson gson = new Gson();
            JsonObject root = gson.fromJson(stringJson, JsonObject.class);

            for (JsonElement elPos : root.getAsJsonArray("checkpoints")) {
                String[] split = elPos.getAsString().split(" ");

                if (split.length < 3) {
                    throw new IllegalArgumentException("Position without x y and z");
                }

                Pos pos = new Pos(Double.parseDouble(split[0]) + 0.5, Double.parseDouble(split[1]) + 0.5,
                        Double.parseDouble(split[2]) + 0.5);

                if (split.length >= 4) {
                    pos = pos.withYaw(Float.parseFloat(split[3]));
                }

                if (split.length >= 5) {
                    pos = pos.withPitch(Float.parseFloat(split[4]));
                }

                mapData.checkpoints.add(pos);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        // Player spawning
        MinecraftServer.getGlobalEventHandler().addListener(AsyncPlayerConfigurationEvent.class, e -> {
            e.setSpawningInstance(instance);
            Player player = e.getPlayer();
            player.setRespawnPoint(mapData.checkpoints.getFirst());
            player.setGameMode(GameMode.ADVENTURE);
            player.getAttribute(Attribute.PLAYER_BLOCK_INTERACTION_RANGE).setBaseValue(-128);
            player.getAttribute(Attribute.PLAYER_ENTITY_INTERACTION_RANGE).setBaseValue(-128);
        });

        MinecraftServer.getGlobalEventHandler().addListener(PlayerMoveEvent.class, e -> {
            Pos newPos = e.getNewPosition();
            Player player = e.getPlayer();

            int currentCheckpoint = player.getTag(CURRENT_CHECKPOINT_TAG);
            for (int i = currentCheckpoint+1; i < mapData.checkpoints.size(); i++) {
                Pos checkpoint = mapData.checkpoints.get(i);
                if (checkpoint.blockX() == newPos.blockX() && checkpoint.blockZ() == newPos.blockZ() &&
                        (checkpoint.blockY() == newPos.blockY() || checkpoint.blockY() + 1 == newPos.blockY())) {

                    if (i != currentCheckpoint + 1) { // this is not the next checkpoint, they skipped a checkpoint
                        player.sendActionBar(Component.text("You skipped a checkpoint!").color(TextColor.color(0.9f, 0.1f, 0.1f)));
                        continue;
                    }

                    player.setRespawnPoint(checkpoint);
                    player.sendActionBar(Component.text("Checkpoint reached!").color(TextColor.color(0.1f, 0.9f, 0.1f)));
                    player.setTag(CURRENT_CHECKPOINT_TAG, i);
                }
            }

            if (instance.getBlock(e.getNewPosition()) == Block.LAVA) {
                player.teleport(player.getRespawnPoint());
            }
        });

        Log.logger().info("Started Parkour game");
    }

    @Override
    public List<Feature<?>> features() {
        return List.of();
    }

    /**
     * @param worldName the world this server is for
     */
    public record Config(String worldName) { }

    public record MapData(List<Pos> checkpoints) { }
}
